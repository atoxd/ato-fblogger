# -Facebook-login-page-HTML-CSS
Facebook login page using HTML and CSS only

Screenshot:
![FB login SS](https://user-images.githubusercontent.com/94108226/141776544-875c3369-2989-4b21-a283-febfd77ca153.jpg)
